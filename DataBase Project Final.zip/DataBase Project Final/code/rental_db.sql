-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : mer. 12 juin 2024 à 16:11
-- Version du serveur : 5.7.39
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `rental_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `cars`
--

CREATE TABLE `cars` (
  `car_id` int(11) NOT NULL,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `color` varchar(50) DEFAULT NULL,
  `vehicle_type` varchar(50) NOT NULL,
  `gearbox_type` enum('automatic','manual') NOT NULL,
  `horsepower` int(11) DEFAULT NULL,
  `doors` int(11) DEFAULT NULL,
  `passenger_capacity` int(11) DEFAULT NULL,
  `suitcase_capacity` int(11) DEFAULT NULL,
  `status` enum('available','rented','maintenance') NOT NULL DEFAULT 'available',
  `current_location_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `cars`
--

INSERT INTO `cars` (`car_id`, `make`, `model`, `year`, `color`, `vehicle_type`, `gearbox_type`, `horsepower`, `doors`, `passenger_capacity`, `suitcase_capacity`, `status`, `current_location_id`, `price`, `image`) VALUES
(2, 'AUDI', 'A3', 2020, 'blue', 'Break', 'automatic', 201, 5, 5, 3, 'available', 2, '259.00', 'audiA3-3.jpeg'),
(3, 'Mercedes', 'Classe A ', 2021, 'Gray', 'Break', 'automatic', 193, 5, 5, 3, 'available', 3, '270.00', 'mercedesA-2.jpeg'),
(4, 'BMW', 'Serie 4', 2023, 'Nardo Gray ', 'Sedan', 'automatic', 210, 5, 5, 3, 'available', 1, '349.00', 'bmwgris1.jpeg'),
(5, 'Land Rover ', 'Range Rover', 2019, 'Red', 'SUV', 'automatic', 308, 5, 5, 5, 'available', 3, '470.00', 'rangerover4.jpeg'),
(6, 'Lamborghini', 'URUS', 2022, 'Yellow', 'SUV', 'automatic', 450, 5, 5, 4, 'available', 2, '599.00', 'urus-5.jpeg'),
(7, 'Porsche', '911 Turbo S', 2020, 'Dark Blue', 'sport/convertible', 'automatic', 650, 3, 4, 1, 'available', 2, '659.00', 'porscheturboS-6.jpeg');

-- --------------------------------------------------------

--
-- Structure de la table `locations`
--

CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `locations`
--

INSERT INTO `locations` (`location_id`, `location_name`, `address`, `city`, `state`, `zip_code`) VALUES
(1, 'Istanbul', 'Beşiktaş/ Bebek / Goztepe Caddesi', 'Istanbul', 'Bebek', '34'),
(2, 'Ankara', 'Kizilay / Serdar Dursun Mahallesi ', 'Ankara ', 'Kizilay', '06'),
(3, 'Yozgat', 'Sefaatli Yozgat / Volkan Demirel Mahallesi ', 'Yozgat ', 'Sefaatli ', '66');

-- --------------------------------------------------------

--
-- Structure de la table `reservations`
--

CREATE TABLE `reservations` (
  `reservation_id` int(11) NOT NULL,
  `car_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `return_location_id` int(11) DEFAULT NULL,
  `pick_up_location_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reservations`
--

INSERT INTO `reservations` (`reservation_id`, `car_id`, `user_id`, `start_date`, `end_date`, `status`, `return_location_id`, `pick_up_location_id`) VALUES
(15, 7, 8, '2024-06-10', '2024-06-15', NULL, 2, 1);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `reset_token`, `token_expiry`, `phone`) VALUES
(1, 'yunus', 'y.demirel467@gmail.com', '$2y$10$K9lcZEJZMcsvtycFZthAE.89iP3W5pDyCzwaGu0iV.uvP27smc5Ca', '9ac9719e8c1cba5f87d4b8480081d72f7d145b5ac2281bcaaf12bf33511bdcc9', '2024-06-07 15:51:39', '553 089 47 86'),
(2, 'yusuf', 'yusufemir66@gmail.com', '$2y$10$7FGKEirjb.ZA.7GjOvCNaucvvAjOHkTlRj2g.YQDQjG35nSpowdPS', NULL, NULL, NULL),
(3, 'ibrahim07', 'ibrahim07ates@gmail.com', '$2y$10$qEUGb9q4eG3inZT.dWnLEuARjwHBrl4a1mLe0Su7YvUDUgAKuMghS', NULL, NULL, NULL),
(4, 'Emre', 'emre.demirel68@gmail.com', '$2y$10$ARy6dB5sTiG773kLwjrrQO.irJHa.U3sjJGaXYSIAyuKkO1k5cRxC', NULL, NULL, '0606'),
(5, 'ibrahim ', 'ibrahimates@gmail.com', '$2y$10$HE7c/Z0qz/BHRJlh8oHfGu.g1FLqCjQBohxltN.fV/OExlgwABUrq', NULL, NULL, '553 765 45 64'),
(6, 'bilal', 'bilal@gmail.com', '$2y$10$Z0Jc7kd0Li2.AE5UrBdz9.F7IddBpFMhjN63.4u62Lw7DoseK.R02', NULL, NULL, '555 555 55 55 '),
(8, 'sahar3', 'sahar@gmail.com', '$2y$10$zJOV9lkDleXMYMiZxvolB.UQxF5k7/x3PERI0O9Svxsw/yeUJ3rhO', NULL, NULL, '544 544 54 54');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_id`),
  ADD KEY `current_location_id` (`current_location_id`);

--
-- Index pour la table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Index pour la table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `car_id` (`car_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cars`
--
ALTER TABLE `cars`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `locations`
--
ALTER TABLE `locations`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `cars`
--
ALTER TABLE `cars`
  ADD CONSTRAINT `cars_ibfk_1` FOREIGN KEY (`current_location_id`) REFERENCES `locations` (`location_id`);

--
-- Contraintes pour la table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`car_id`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
